class Player

	#Initializes the name instance variable.
	def initialize(name = nil)
   		@name = name
   
  	end
end
